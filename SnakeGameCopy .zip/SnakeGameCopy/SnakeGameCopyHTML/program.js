async function __qbjs_run() {
QB.start(); QB.setTypeMap({ GXPOSITION:[{ name: 'x', type: 'LONG' }, { name: 'y', type: 'LONG' }], GXDEVICEINPUT:[{ name: 'deviceId', type: 'INTEGER' }, { name: 'deviceType', type: 'INTEGER' }, { name: 'inputType', type: 'INTEGER' }, { name: 'inputId', type: 'INTEGER' }, { name: 'inputValue', type: 'INTEGER' }], FETCHRESPONSE:[{ name: 'ok', type: 'INTEGER' }, { name: 'status', type: 'INTEGER' }, { name: 'statusText', type: 'STRING' }, { name: 'text', type: 'STRING' }]});
    await GX.registerGameEvents(function(e){});
    QB.sub_Screen(0);

   QB.sub_Cls(undefined, undefined);
   QB.sub__Title( "SNAKE GAME");
   QB.sub_Screen( (QB.func__NewImage(  640 ,    480 ,    256)));
   var is_fullscreen = 0;  /* INTEGER */ 
   QB.sub_Randomize(false, QB.func_Timer())
   var score = 0;  /* INTEGER */ 
   const MAX_SNAKE_LENGTH  =    500; 
   var snakeArray = QB.initArray([{l:1,u:MAX_SNAKE_LENGTH},{l:0,u:1}], 0);  /* INTEGER */ 
   var x = '';  /* STRING */ 
   var y = 0;  /* INTEGER */ 
   foodx =  (QB.func_Int( QB.func_Rnd() *  74))  +  3;
   foody =  (QB.func_Int( QB.func_Rnd() *  21))  +  3;
   var sn = 0;  /* INTEGER */ 
   var snakeX = 0;  /* INTEGER */ 
   var snakeY = 0;  /* INTEGER */ 
   var snakeXd = 0;  /* INTEGER */ 
   var snakeYd = 0;  /* INTEGER */ 
   var snakeSnakeLength = 0;  /* INTEGER */ 
   var snakeAnim = 0;  /* INTEGER */ 
   var snakeDied = 0;  /* INTEGER */ 
   snakeX =   15;
   snakeY =   31;
   snakeDied =   0;
   snakeYd =   1;
   snakeXd =   0;
   snakeSnakeLength =   1;
   var keypress = '';  /* STRING */ 
   var snakeSpeed = 0;  /* INTEGER */ 
   snakeSpeed =  (await func_speed_choices(  snakeSpeed));
   var ___v7055475 = 0; do { if (QB.halted()) { return; }___v7055475++;   if (___v7055475 % 100 == 0) { await QB.autoLimit(); }
      keypress =  QB.func_InKey();
      keypress =  (QB.func_UCase(  keypress));
      if ( keypress ==  (QB.func_Chr(  0))  + (QB.func_Chr(  72))  ||  keypress ==  "W"  ) {
         if ( snakeYd !=   1 ) {
            snakeXd =   0;
            snakeYd =   - 1;
         }
      } else if ( keypress ==  (QB.func_Chr(  0))  + (QB.func_Chr(  80))  ||  keypress ==  "S"  ) {
         if ( snakeYd !=   - 1 ) {
            snakeXd =   0;
            snakeYd =   1;
         }
      } else if ( keypress ==  (QB.func_Chr(  0))  + (QB.func_Chr(  77))  ||  keypress ==  "D"  ) {
         if ( snakeXd !=   - 1 ) {
            snakeXd =   1;
            snakeYd =   0;
         }
      } else if ( keypress ==  (QB.func_Chr(  0))  + (QB.func_Chr(  75))  ||  keypress ==  "A"  ) {
         if ( snakeXd !=   1 ) {
            snakeXd =   - 1;
            snakeYd =   0;
         }
      } else if ( keypress ==  "B"  ) {
         QB.sub_Beep();
         window.open('https://skyquestweb.wordpress.com/', '_blank');
      } else if ( keypress ==  "F"  ) {
         QB.sub_Beep();
         if ( is_fullscreen ==   0 ) {
            is_fullscreen =   1;
            QB.sub__FullScreen(QB.STRETCH, false);
         } else {
            is_fullscreen =   0;
            QB.sub__FullScreen(QB.OFF, false);
         }
      }
      snakeX =   snakeX +  snakeXd;
      snakeY =   snakeY +  snakeYd;
      if ( snakeX < 4 ) {
         snakeX =   77;
      } else if ( snakeX > 77 ) {
         snakeX =   4;
      } else if ( snakeY < 2 ) {
         snakeY =   25;
      } else if ( snakeY > 25 ) {
         snakeY =   2;
      }
      var ___v5334240 = 0; for ( sn=  2 ;  sn <=  snakeSnakeLength;  sn= sn + 1) { if (QB.halted()) { return; } ___v5334240++;   if (___v5334240 % 100 == 0) { await QB.autoLimit(); }
         if ( snakeY ==  QB.arrayValue(snakeArray, [ sn ,   0]).value  &&  snakeX ==  QB.arrayValue(snakeArray, [ sn ,   1]).value  ) {
            snakeDied =   - 1;
            QB.sub_Beep();
         }
      }
      if ( snakeX ==   foodx &&  snakeY ==   foody ) {
         score =   score +  1;
         snakeAnim =   1;
         QB.sub_Beep();
         var ___v5795186 = 0; while ( foodx ==   snakeX &&  foody ==   snakeY) { if (QB.halted()) { return; }___v5795186++;   if (___v5795186 % 100 == 0) { await QB.autoLimit(); }
            foodx =  (QB.func_Int( QB.func_Rnd() *  74))  +  3;
            foody =  (QB.func_Int( QB.func_Rnd() *  21))  +  3;
         }
         snakeSnakeLength =   snakeSnakeLength +  1;
      }
      if ( snakeDied) {
         keypress =  (QB.func_Chr(  27));
      }
      QB.sub_Cls(undefined, undefined);
      QB.sub_Line(false,  20 ,   10, false,  620 ,   400,    15 , 'B', undefined);
      QB.sub_Color(  2);
      QB.sub_Locate(  foody ,    foodx);
      await QB.sub_Print([(QB.func_Chr(  6))]);
      QB.sub_Color(  15);
      QB.arrayValue(snakeArray, [ 1 ,   0]).value =   snakeY;
      QB.arrayValue(snakeArray, [ 1 ,   1]).value =   snakeX;
      var ___v2895625 = 0; for ( sn=  snakeSnakeLength;  sn >=  1 ;  sn= sn +  - 1) { if (QB.halted()) { return; } ___v2895625++;   if (___v2895625 % 100 == 0) { await QB.autoLimit(); }
         QB.arrayValue(snakeArray, [ sn +  1 ,   0]).value =  QB.arrayValue(snakeArray, [ sn ,   0]).value;
         QB.arrayValue(snakeArray, [ sn +  1 ,   1]).value =  QB.arrayValue(snakeArray, [ sn ,   1]).value;
         QB.sub_Color(  4);
         QB.sub_Locate( QB.arrayValue(snakeArray, [ sn ,   0]).value  ,   QB.arrayValue(snakeArray, [ sn ,   1]).value);
         await QB.sub_Print(["Û"]);
         QB.sub_Color(  15);
      }
      QB.arrayValue(snakeArray, [ 1 ,   0]).value =   snakeY;
      QB.arrayValue(snakeArray, [ 1 ,   1]).value =   snakeX;
      QB.sub_Color(  12);
      if ( snakeAnim ==   0 ) {
         QB.sub_Locate(  snakeY,    snakeX);
         await QB.sub_Print([(QB.func_Chr(  2))]);
      } else if ( snakeAnim ==   1 ) {
         QB.sub_Locate(  snakeY,    snakeX);
         await QB.sub_Print([(QB.func_Chr(  1))]);
      }
      QB.sub_Color(  15);
      QB.sub_Locate(  27 ,    3);
      await QB.sub_Print(["SCORE:",QB.PREVENT_NEWLINE, (QB.func_Str(  score)),QB.PREVENT_NEWLINE, "   (Press B for website, Press F for fullscreen)"]);
      QB.sub__Display();
      snakeAnim =   0;
      if ( snakeSpeed ==   1 ) {
         await QB.sub__Limit(  7);
      } else if ( snakeSpeed ==   2 ) {
         await QB.sub__Limit(  14);
      } else if ( snakeSpeed ==   3 ) {
         await QB.sub__Limit(  20);
      }
   } while (!( keypress ==  (QB.func_Chr(  27))))
   QB.halt(); return;
QB.end();

async function func_speed_choices(snakeSpeed/*INTEGER*/) {
if (QB.halted()) { return; }
var speed_choices = null;
   await QB.sub_Print(["1. EASY"]);
   await QB.sub_Print(["2. MEDIUM"]);
   await QB.sub_Print(["3. HARD"]);
   var ___v3019480 = new Array(1); await QB.sub_Input(___v3019480, false, true, "ENTER SNAKE SPEED");  snakeSpeed = QB.toInteger(___v3019480[0]); 
   QB.sub_Beep();
   var ___v7747401 = 0; while ( snakeSpeed !=   1 &&  snakeSpeed !=   2 &&  snakeSpeed !=   3) { if (QB.halted()) { return; }___v7747401++;   if (___v7747401 % 100 == 0) { await QB.autoLimit(); }
      await QB.sub_Print(["INVALID, Please enter 1 or 2 or 3"]);
      var ___v140176 = new Array(1); await QB.sub_Input(___v140176, false, true, "ENTER SNAKE SPEED");  snakeSpeed = QB.toInteger(___v140176[0]); 
      QB.sub_Beep();
   }
   speed_choices =   snakeSpeed;
return speed_choices;
}

}